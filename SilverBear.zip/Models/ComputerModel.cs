using System;

namespace SilverBear
{
    public class ComputerModel
    {
        public ComputerModel()
        {

        }

        public int ID { get; set; }
        public string Ram { get; set; }
        public string Harddrive { get; set; }
        public string Peripherals { get; set; }
        public string GraphicsCard { get; set; }
        public string Weight { get; set; }
        public string Power { get; set; }
        public string CPU { get; set; }
        public bool Edit { get; set; }
    }
}

/*

{
    "Ram": "8 GB",
   "Harddrive": "1 TB SSD",
   "Peripherals": "2 x USB 3.0, 4 x USB 2.0",
   "GraphicsCard": "NVIDIA GeForce GTX 770",
   "Weight": "8.1 kg",
   "Power": "500 W PSU",
   "CPU": "�Intel� Celeron� N3050 Processor"
 }
*/