import { Component, EventEmitter, Inject, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ComputerModel } from '../models/computer-model';

@Component({
  selector: 'sb-computers-add',
  templateUrl: './computers-add.component.html'
})
export class ComputersAddComponent {


  @Output() onSave: EventEmitter<boolean> = new EventEmitter();  
  model: ComputerModel;
  ram: 'rammy';

  constructor(private http: HttpClient, @Inject('BASE_URL') private baseUrl: string) {

    this.model = {
      ID: -1,
      CPU: '1',
      Edit: false,
      GraphicsCard: '',
      Harddrive: '',
      Peripherals: '',
      Power: '',
      Ram: '',
      Weight: ''
    };

  }


  saveComputer() {

    let url = this.baseUrl + 'computers/saveComputer';

    this.http.post(url, this.model).subscribe(result => {

      this.onSave.emit(true);

    }, error => {
      alert('Could not save computer');
      console.error(error)
    });
  }
}

