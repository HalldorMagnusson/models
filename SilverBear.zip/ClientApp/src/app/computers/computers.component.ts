import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ComputerModel } from '../models/computer-model';

@Component({
  selector: 'sb-computers',
  templateUrl: './computers.component.html'
})
export class ComputersComponent {

  public computers: ComputerModel[];
  addComputerVisible = false;

  constructor(private http: HttpClient, @Inject('BASE_URL') private baseUrl: string) {

    this.getComputers();
  }

  private getComputers() {

    this.http.get<ComputerModel[]>(this.baseUrl + 'computers').subscribe(result => {
      this.computers = result;
    }, error => {
      alert('Could not get a list of computers');
      console.error(error)
    });
  }

  public editComputer(computer: ComputerModel) {

    computer.Edit = !computer.Edit;
  }

  public updateComputer(computer: ComputerModel) {
    
    let url = this.baseUrl + 'computers/updateComputer';

    this.http.post(url, computer).subscribe(result => {

      computer.Edit = false;
    }, error => {
      alert('Could not get a list of computers');
      console.error(error)
    });
  }

  public sortBy(column) {

    switch (column) {
      case 'Ram':
        this.computers.sort((a, b) => (a.Ram > b.Ram ? 1 : -1));
        break;
      case 'CPU':
        this.computers.sort((a, b) => (a.CPU > b.CPU ? 1 : -1));
        break;
      case 'GraphicsCard':
        this.computers.sort((a, b) => (a.GraphicsCard > b.GraphicsCard ? 1 : -1));
        break;
      case 'Harddrive':
        this.computers.sort((a, b) => (a.Harddrive > b.Harddrive ? 1 : -1));
        break;
      case 'Peripherals':
        this.computers.sort((a, b) => (a.Peripherals > b.Peripherals ? 1 : -1));
        break;
      case 'Power':
        this.computers.sort((a, b) => (a.Power > b.Power ? 1 : -1));
        break;
      case 'Weight':
        this.computers.sort((a, b) => (a.Weight > b.Weight ? 1 : -1));
        break;      
    }
  }

  public deleteComputer(computer: ComputerModel) {

    if (confirm('Are you sure you wish to remove this computer from the list' )) {

      let url = this.baseUrl + 'computers/deleteComputer?ID=' + computer.ID;

      this.http.delete(url).subscribe(result => {

        this.getComputers();

      }, error => {
        alert('Could not get a list of computers');
        console.error(error)
      });
    } 
  }

  public setAddComputerVisible() {

    this.addComputerVisible = !this.addComputerVisible;

  }

  public computerAdded() {
    this.addComputerVisible = false;
    this.getComputers();

  }

}

