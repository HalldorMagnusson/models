


export interface ComputerModel {
  ID: number;
  Ram: string;
  Harddrive: string;
  Peripherals: string;
  GraphicsCard: string;
  Weight: string;
  Power: string;
  CPU: string;
  Edit: boolean;

}
