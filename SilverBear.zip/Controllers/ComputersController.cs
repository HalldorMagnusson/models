﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SilverBear.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace SilverBear.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ComputersController : ControllerBase
    {
      

        private readonly ILogger<ComputersController> _logger;
        private const string COMPUTERS_PATH = @"Data/computers.json";

        public ComputersController(ILogger<ComputersController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public string Get()
        {
            string computersJson = string.Empty;
            computersJson = System.IO.File.ReadAllText(COMPUTERS_PATH);
            return computersJson;            
        }

                
        [Route("updateComputer")]
        public bool UpdateComputer(ComputerModel model)
        {
            string computersJson = string.Empty;

            try
            {
                computersJson = System.IO.File.ReadAllText(COMPUTERS_PATH);
                List<ComputerModel> computers = (List<ComputerModel>) JsonSerializer.Deserialize(computersJson, typeof(List<ComputerModel>));                
                var computer = computers.Single(x => x.ID == model.ID);
                model.CopyProperties(computer);
                computer.Edit = false;

                string updatedJson = JsonSerializer.Serialize<List<ComputerModel>>(computers);
                System.IO.File.WriteAllText(COMPUTERS_PATH, updatedJson);

                return true;
            }
            catch(Exception e)
            {
                this._logger.LogError(e, $"Could not update computer with id {model.ID}");                
                return false;
            }
        }

        [Route("deleteComputer")]
        public bool DeleteComputer(int ID)
        {
            string computersJson = string.Empty;

            try
            {
                computersJson = System.IO.File.ReadAllText(COMPUTERS_PATH);
                List<ComputerModel> computers = (List<ComputerModel>)JsonSerializer.Deserialize(computersJson, typeof(List<ComputerModel>));
                computers.RemoveAll(x => x.ID == ID);
                string updatedJson = JsonSerializer.Serialize<List<ComputerModel>>(computers);
                System.IO.File.WriteAllText(COMPUTERS_PATH, updatedJson);

                return true;
            }
            catch (Exception e)
            {
                this._logger.LogError(e, $"Could not delete computer with id {ID}");
                return false;
            }
        }

        [Route("saveComputer")]
        public bool SaveComputer(ComputerModel model)
        {
            string computersJson = string.Empty;

            try
            {
                computersJson = System.IO.File.ReadAllText(COMPUTERS_PATH);
                List<ComputerModel> computers = (List<ComputerModel>)JsonSerializer.Deserialize(computersJson, typeof(List<ComputerModel>));
                int maxID = computers.Max(x => x.ID);
                model.ID = maxID + 1;
                computers.Add(model);
                string updatedJson = JsonSerializer.Serialize<List<ComputerModel>>(computers);
                System.IO.File.WriteAllText(COMPUTERS_PATH, updatedJson);

                return true;
            }
            catch (Exception e)
            {
                this._logger.LogError(e, $"Could not add new computer");
                return false;
            }
        }
    }
}
